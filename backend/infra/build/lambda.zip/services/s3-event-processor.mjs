// s3-event-processor.mjs
export class S3EventProcessor {
  isValidS3Event(record) {
    return (
      record.eventSource === 'aws:s3' &&
      record.eventName?.startsWith('ObjectCreated:')
    );
  }

  extractS3Data(record) {
    const bucket = record.s3.bucket.name;
    const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
    const versionId = record.s3.object.versionId || null;

    return { bucket, key, versionId };
  }

  processEventRecords(event) {
    const records = event.Records || [];
    const validRecords = records.filter((record) => this.isValidS3Event(record));

    console.log('S3 event processed', { total: records.length, valid: validRecords.length });

    return validRecords;
  }
}
